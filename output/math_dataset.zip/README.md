# Math Handwriting Dataset

This dataset contains 33318 images of handwritten mathematical expressions.

## Structure

- `images/`: Directory containing all image files
- `labels.csv`: CSV file with image paths and labels

## Usage in Python

```python
import pandas as pd
from PIL import Image

# Load the labels
df = pd.read_csv('labels.csv')

# Load an image
image = Image.open(df.iloc[0]['image_path'])
label = df.iloc[0]['label']  # Adjust column name as needed
```
